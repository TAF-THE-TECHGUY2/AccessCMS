window.__APP_CONFIG__ = {
  apiBaseUrl: "https://api.ap.boston"
};
