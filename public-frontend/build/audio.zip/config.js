window.__APP_CONFIG__ = {
  apiBaseUrl: "https://api.ap.boston"
}; 
/*w
window.__APP_CONFIG__ = {
  apiBaseUrl: "http://localhost:5000"
};*/
